﻿using System;

namespace Punto4
{
    class Program
    {
        static void Main(string[] args)
        {
            // 4. Se cargan por teclado tres números distintos. Mostrar por pantalla el mayor de ellos.

            int num1, num2, num3;
            string linea;

            Console.Write("Ingrese el primer numero: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("Ingrese el segundo numero: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            Console.Write("Ingrese el tercer numero: ");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);

            if (num1 > num2 && num1 > num3)
            {
                Console.Write("El mayor es: " + num1);
            }
            else
            {
                if (num2 > num3)
                {
                    Console.Write("El mayor es: " + num2);
                }
                else
                {
                    Console.Write("El mayor es: " + num3);
                }
            }

            Console.ReadKey();
        }
    }
}
