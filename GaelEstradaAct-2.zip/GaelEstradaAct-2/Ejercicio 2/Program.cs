﻿using System;

namespace Punto2
{
    class Program
    {
        static void Main(string[] args)
        {
            // 2. Se ingresan seis notas de un alumno, si el promedio es mayor o igual a siete mostrar un mensaje "Promocionado"

            float nota1, nota2, nota3, nota4, nota5, nota6, promedio;
            string linea;

            Console.Write("Ingrese nota 1: ");
            linea = Console.ReadLine();
            nota1 = float.Parse(linea);

            Console.Write("Ingrese nota 2: ");
            linea = Console.ReadLine();
            nota2 = float.Parse(linea);

            Console.Write("Ingrese nota 3: ");
            linea = Console.ReadLine();
            nota3 = float.Parse(linea);

            Console.Write("Ingrese nota 4: ");
            linea = Console.ReadLine();
            nota4 = float.Parse(linea);

            Console.Write("Ingrese nota 5: ");
            linea = Console.ReadLine();
            nota5 = float.Parse(linea);

            Console.Write("Ingrese nota 6: ");
            linea = Console.ReadLine();
            nota6 = float.Parse(linea);

            promedio = (nota1 + nota2 + nota3 + nota4 + nota5 + nota6) / 6;

            if (promedio >= 7)
            {
                Console.Write("Promocionado");
            }

            Console.ReadKey();
        }
    }
}
