﻿using System;

namespace Punto3
{
    class Program
    {
        static void Main(string[] args)
        {
            // 3. Se ingresa por teclado un número positivo de uno o dos dígitos (1..99)
            // mostrar un mensaje indicando si el número tiene uno o dos dígitos.

            int numero;
            string linea;

            Console.Write("Ingrese un numero entre 1 y 99: ");
            linea = Console.ReadLine();
            numero = int.Parse(linea);

            if (numero >= 10)
            {
                Console.Write("El numero tiene dos digitos");
            }
            else
            {
                Console.Write("El numero tiene un digito");
            }

            Console.ReadKey();
        }
    }
}
