﻿using System;

namespace Punto1
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. Realizar un programa que lea por teclado dos números, si el primero es mayor al segundo
            // informar su suma y diferencia, en caso contrario informar el producto y la división del primero respecto al segundo.

            float num1, num2, suma, resta, producto, division;
            string linea;

            Console.Write("Ingrese el primer numero: ");
            linea = Console.ReadLine();
            num1 = float.Parse(linea);

            Console.Write("Ingrese el segundo numero: ");
            linea = Console.ReadLine();
            num2 = float.Parse(linea);

            if (num1 > num2)
            {
                suma = num1 + num2;
                resta = num1 - num2;

                Console.Write("La suma es: " + suma);
                Console.WriteLine();
                Console.Write("La diferencia es: " + resta);
            }
            else
            {
                producto = num1 * num2;
                division = num1 / num2;

                Console.Write("El producto es: " + producto);
                Console.WriteLine();
                Console.Write("La division es: " + division);
            }

            Console.ReadKey();
        }
    }
}
